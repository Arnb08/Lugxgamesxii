📍 Lugx Gaming Shop

## ❕ Lugx Gaming Shop is an online gaming shop website template , that developed with html, css and javascript and fully responsive to provide a good user experience to the site user.

### 🔗 Website URL : https://moein-developer1.github.io/Lugx-gaming-shop/

### ✍ Developers => 👨‍💼 Name: Mohammad Moein ghiyasvand , 📧 Email: moeinghiasvand11@gmail.com

### 📝 Project status: The development of this project has been completed .

#### 📌 This project is just an example for resume
